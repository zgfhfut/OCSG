1、harsh(agent:goal=2:3)、relax（agent：goal=3:1）
2、本实验agent、goal、interest是ACM文章的，而cost和reward是用的自己生成的。一共30套